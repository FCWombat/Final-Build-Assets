using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IBossInterface
{
    public void Attack();
    public int getAttackParams();
    public void hit();
}
