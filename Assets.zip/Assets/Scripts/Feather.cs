using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Feather : MonoBehaviour
{
    public bool direction;
    public float speed;
    public int msDelay;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(wait(msDelay)); 
    }
    IEnumerator wait(int ms)
    {
        float spd = speed;
        speed = 0.0f;
        yield return new WaitForSeconds(ms / 1000.0f);
        speed = spd;
    }

    // Update is called once per frame
    void Update()
    {
        float xVelocity = direction ? speed : -speed;
        transform.Translate(xVelocity, 0f, 0f);
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Segment")
        {
            other.gameObject.GetComponent<segment>().damaged = true;
            Debug.Log("collision between segment and feather detected");
            Destroy(this.gameObject);
        }
        if (other.tag == "ProjectileLimit")
        {
            Debug.Log("collision between wall and feather detected");
            Destroy(this.gameObject);
        }
        if(other.tag == "Player")
        {
            other.gameObject.GetComponent<Snake>().lose();
        }
    }
}
