using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class SecreteryBird : MonoBehaviour, IBossInterface
{
    public Boss boss;
    public Apple eggplant;
    public Snake snake;
    public Transform projectilePrefab;
    public int feathersUntilStomp;
    public Transform stompPrefab;
    public Transform shadowPrefab;
    private Transform stompObject;
    private Transform shadowObject;
    public bool leftAttack;
    public bool rightAttack;
    public bool stomp;
    public Stomp stompBird;
    public float stompSpeed;
    public bool isStomping;
    // Start is called before the first frame update
    void Start()
    {
        feathersUntilStomp = Random.Range(5, 10);
        boss.bossAI = this;
    }

    // Update is called once per frame
    void Update()
    {
        if(leftAttack == false)
        {
            GetComponent<Animator>().SetBool("leftAttack", false);
        }
        if (rightAttack == false)
        { //I commented my code
            GetComponent<Animator>().SetBool("rightAttack", false);
        }
        if (stomp == false)
        {
            GetComponent<Animator>().SetBool("Stomp", false);
        }
        if (isStomping)
        {
            stompObject.gameObject.transform.position = new Vector3(stompObject.gameObject.transform.position.x, stompObject.gameObject.transform.position.y - stompSpeed, stompObject.gameObject.transform.position.z);
        }
    }
    public void Attack()
    {
      //  if(feathersUntilStomp > 0)
        //{
            featherAttack(getAttackParams());
        //}
        //else
        //{
          //  stompAttack();
            //feathersUntilStomp = Random.Range(5, 10);
        //}
    }
    public void featherAttack(int headPos)
    {
        bool direction = (feathersUntilStomp % 2 == 1); //true = left, false = right
        if (direction)
        {
            GetComponent<Animator>().SetBool("leftAttack", true);
            leftAttack = true;
        }
        else
        {
            GetComponent<Animator>().SetBool("rightAttack", true);
            rightAttack = true;
        }
        //play animation based on direction
        //wait for animation to finish and feathers to go offscreen
        //once off screen, do the stuff below this
        Transform feather = Instantiate(projectilePrefab);
        Feather featherAI = feather.GetComponent<Feather>();
        float x = direction ? -60f : 60f;
        feather.position = new Vector3(x, snake.GetComponent<Transform>().position.y, 0f);
        featherAI.direction = direction;
        feathersUntilStomp--;
    }
    public void stompAttack()
    {
        GetComponent<Animator>().SetBool("Stomp", true);
        stomp = true;
        //play animation
        //spawn shadow on the ground where head was
        stompObject.gameObject.transform.position = new Vector3(eggplant.transform.position.x,stompObject.gameObject.transform.position.y, stompObject.gameObject.transform.position.z);
        //set x position to eggplant x position. see i commented
        StartCoroutine(Shadow(1500));
        //play animation
        //disable hitbox for secretery bird
        //spawn invisible hitbox for damage
        //check if damage
        //play animation
        //delete hitbox


    }
    IEnumerator Shadow(int ms)
    {
        yield return new WaitForSeconds(ms / 1000.0f);
        Vector3 location = eggplant.transform.position;
        shadowObject = Instantiate(shadowPrefab, location, new Quaternion());
        StartCoroutine(wait(3000, location));
    }
    IEnumerator wait(int ms, Vector3 location)
    {
        yield return new WaitForSeconds(ms / 1000.0f);
        //move the sprite down
        if (stompBird.gameObject.transform.position.y > eggplant.gameObject.transform.position.y)
        {
            isStomping = true;
        }
        else
        {
            isStomping = false;
        }
        StartCoroutine(wait2(2000));
    }
    IEnumerator wait2(int ms)
    {
        yield return new WaitForSeconds(ms / 1000.0f);
        Destroy(shadowObject.gameObject);
        Destroy(stompObject.gameObject);
    }
    public int getAttackParams()
    {
        return Mathf.FloorToInt(snake.transform.position.x);
    }
    public void hit()
    {
        Debug.Log("Bird Hit");
        boss.health--;
        if (boss.health <= 0)
        {
            Destroy(this.gameObject);
            SceneManager.LoadScene("Ouro_Splash");
        }
    }
}
