using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class stompHitbox : MonoBehaviour
{
    public Boss boss;
    public bool alive;
    // Start is called before the first frame update
    void Start()
    {
        alive = true;
        boss = FindObjectOfType<Boss>();
    }

    // Update is called once per frame
    void Update()
    {
        if(alive == false)
        {
            Destroy(this);
        }
    }
    public void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Segment")
        {
            other.gameObject.GetComponent<segment>().damaged = true;
            Debug.Log("collision between segment and bird detected");
        }
        if (other.tag == "Player")
        {
            other.gameObject.GetComponent<Snake>().lose();
        }
        if (other.tag == "Food")
        {
            if (other.gameObject.GetComponent<Apple>().big)
            {
                boss.health += 2;
            }
            else
            {
                boss.health++;
            }
            if (boss.health > boss.maxHealth)
            {
                boss.health = boss.maxHealth;
            }
            other.gameObject.GetComponent<Apple>().RandomizePosition();
        }
    }
}
